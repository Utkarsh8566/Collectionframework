package com.setexample.collectionCall;
import java.util.HashSet;
import java.util.Set;

public class SetExample {
    public static void main(String[] args) {
        // Creating a Set of Strings
        Set<String> set = new HashSet<>();

      
        set.add("Apple");
        set.add("Banana");
        set.add("Cherry");
        set.add("Apple"); // Duplicates will be ignored

        // Displaying elements
        System.out.println("Set Elements: " + set);

        // Removing an element
        set.remove("Banana");
        System.out.println("After removing 'Banana': " + set);

        // Iterating over set
        System.out.println("Iterating over Set:");
        for (String item : set) {
            System.out.println(item);
        }
    }
}
